import React, { useState, useEffect } from 'react';
import { Alert, StyleSheet, Text, View, Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';
import { auth } from './firebase'


const Stack = createNativeStackNavigator();


export default function App() {

  const handleSignOut = () => {
    auth
      .signOut()
      .then(() => {
        navigation.replace("Login")
      })
      .catch(error => alert(error.message))
  }

  return (
    <NavigationContainer 
    screenOptions={{
      headerShown: false
    }}>
      <Stack.Navigator>
        <Stack.Screen options={{ headerShown: false }} name="Login" component={LoginScreen} />
        <Stack.Screen options={{ 
          headerShown: true, 
          title: 'HydroQuo', headerStyle: {
            backgroundColor: '#5e8fdc',
            alignItems: 'center'
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          }, 
          headerRight: () => (
            <Button
              onPress={() => handleSignOut()}
              title="Sign Out"
              textColor="#81d4f9"
            />
          ),
          }} 
          name="Home" component={HomeScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

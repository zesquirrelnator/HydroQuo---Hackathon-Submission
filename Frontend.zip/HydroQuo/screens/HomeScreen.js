import { useNavigation } from '@react-navigation/core';
import React, { useState, useEffect, useLayoutEffect } from 'react';
import { StyleSheet, TouchableOpacity, View, Button, Modal, Text } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import { auth } from '../firebase';
import axios from 'axios';
import { shadow } from 'react-native-paper';

const mapStyle = [
  {
    "featureType": "administrative.land_parcel",
    "elementType": "labels",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "poi.business",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.icon",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "road.local",
    "elementType": "labels",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  },
  {
    "featureType": "transit",
    "stylers": [
      {
        "visibility": "off"
      }
    ]
  }
];

const HomeScreen = () => {
  const navigation = useNavigation();
  const [location, setLocation] = useState(null);
  const [waterSites, setWaterSites] = useState([]);
  const [waterSiteData, setWaterSiteData] = useState({});
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedWaterSite, setSelectedWaterSite] = useState({});
  const [productRecommendation, setProduct] = useState({});



  const handleSignOut = () => {
    auth
      .signOut()
      .then(() => {
        navigation.replace('Login');
      })
      .catch((error) => alert(error.message));
  };

  useLayoutEffect(() => {
    navigation.setOptions({
      headerShown: true,
      title: 'HydroQuo',
      headerStyle: {
        backgroundColor: '#5e8fdc',
        alignItems: 'center',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
      headerRight: () => (
        <Button onPress={handleSignOut} title="Sign Out" textColor="#81d4f9" />
      ),
    });
  }, [navigation]);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        return;
      }
      console.log("hi!")
      try {
        const response = await axios.get('https://us-central1-hydroquo.cloudfunctions.net/api/api/water_sites');
        setWaterSites(response.data);

        const fetchedWaterSiteData = {};
        for (const site of response.data) {
          const siteResponse = await axios.get(`https://us-central1-hydroquo.cloudfunctions.net/api/api/water_site/${site.waterSite}`);
          fetchedWaterSiteData[site.waterSite] = siteResponse.data;
        }
        setWaterSiteData(fetchedWaterSiteData);

      } catch (error) {
        console.error('Error fetching water sites:', error);
      }

      let location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
        enableHighAccuracy: true,
        timeInterval: 5
      });
      setLocation({
        
      });
    })();
  }, []);

  const onMarkerPress = (siteKey) => {
    setSelectedWaterSite(waterSiteData[siteKey] || {});
    setModalVisible(true);
  };

  const ModalContent = ({ site }) => {

    const recommendedPurification = (score) => {
      if (score < 4) {
        return 'Grayl Ultralight Purifier: Electro Adsorption and Ultra-Powdered Activated Carbon';
      } else if (score >= 4 && score <= 7) {
        return 'Sawyer Products Mini Water Filtration System: Micro Fibrous Tubes Technology';
      } else {
        return 'Lifestraw: Uses Hollow Fiber Membrane Technology (Light)';
      }
    };

    return (
      <>
        <Text style={styles.modalTitle}>{site.siteID}</Text>
        {Object.entries(site).map(([key, value]) => {
            if (value && key !== 'healthinessScore' && key !== 'siteID') {
              if(key === 'Ammonia and ammonium' || key.includes('itrogen') || key.includes('Carbon') || key.includes('Acidity') ){
                return (
                  <Text key={key} style={styles.modalText}>
                    {key}: {value} mg/l
                  </Text>
                );
              }
              else {
                if(key === 'Temperature'){
                  return (
                    <Text key={key} style={styles.modalText}>
                      {key}: {value} Celcius
                    </Text>
                  );
                } else {
                  return (
                    <Text key={key} style={styles.modalText}>
                      {key}: {value} units
                    </Text>
                  );
                }
              }
              
            }
            return null;
          })}
        <Text style={styles.modalScore}>Healthiness Score: {site.healthinessScore}</Text>
        <Text style={styles.modalScore}>Recommended Purification Technology: {recommendedPurification(site.healthinessScore)}</Text>

      </>
    );
  };

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        customMapStyle={mapStyle}
        provider={PROVIDER_GOOGLE}
        showsUserLocation={true}
        initialRegion={{
          latitude: 39.833333,
          longitude: -98.583333,
          latitudeDelta: 30,
          longitudeDelta: 30
        }}
      >
        {waterSites.map((site) => {
          if (!waterSiteData[site.waterSite]) {
            return null;
          }

          return (
            <Marker
              key={site.waterSite}
              coordinate={{
                latitude: waterSiteData[site.waterSite]?.Latitude,
                longitude: waterSiteData[site.waterSite]?.Longitude,
              }}
              onPress={() => onMarkerPress(site.waterSite)}
            >
              <View style={styles.circle}>
                <Text style={styles.pinText}></Text>
              </View>
            </Marker>
          )
        })}
      </MapView>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(!modalVisible);
        }}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <ModalContent site={selectedWaterSite} />
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setModalVisible(!modalVisible)}
            >
              <Text style={styles.textStyle}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  map: {
    width: '100%',
    height: '100%',
  },
  numberContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  numberText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  buttonsContainer: {
    flexDirection: 'row',
  },
  button: {
    backgroundColor: '#2196F3',
    padding: 8,
    paddingHorizontal: 12,
    marginLeft: 10,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  circle: {
    borderRadius: 5,
    width: 10,
    height: 10,
    backgroundColor: '#db2c43',
    opacity: 0.8,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  modalView: {
    width: '80%',
    height: '60%',
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  closeButton: {
    backgroundColor: '#2196F3',
    borderRadius: 20,
    padding: 10,
    paddingHorizontal: 20,
    marginTop: 20,
    elevation: 2,
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
    color: 'black',
  },
  modalText: {
    fontSize: 12,
    marginBottom: 5,
  },
  modalScore: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
  },
});

export default HomeScreen;


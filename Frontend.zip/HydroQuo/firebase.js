import firebase from 'firebase/compat/app'
import 'firebase/compat/auth';


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyALeBc7uWoJZJHBjaUgY9_W9bv0sUJRqcU",
  authDomain: "hydroquo.firebaseapp.com",
  projectId: "hydroquo",
  storageBucket: "hydroquo.appspot.com",
  messagingSenderId: "774716620938",
  appId: "1:774716620938:web:55b8bcc5dc2e8d6bb9ed73"
};

if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig)
}

const auth = firebase.auth();

export { auth };